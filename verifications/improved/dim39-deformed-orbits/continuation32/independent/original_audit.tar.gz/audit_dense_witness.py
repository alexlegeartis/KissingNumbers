from pathlib import Path
import json,hashlib
p=Path(__file__).parent
source=p.parent/'actual_support39_certificate_20261106/source/orbit_certificate.json'
r=json.loads((p/'dense_result.json').read_text());raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['certificate_sha256'];c=json.loads(raw)
i,j,g=r['witness'];v=c['representatives'][i];w=c['representatives'][j];d=sum(x*y*(1-2*((g>>k)&1)) for k,(x,y) in enumerate(zip(v,w)));a=sum(x*x for x in v);b=sum(y*y for y in w)
assert d==r['maximum_integer_dot'] and 4*d*d<=a*b
assert d<=c['norm_lower']**2//2
print('PASS: exact maximum witness',i,j,g,d)
